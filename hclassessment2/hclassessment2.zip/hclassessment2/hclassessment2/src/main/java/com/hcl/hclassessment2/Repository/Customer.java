package com.hcl.hclassessment2.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

public interface Customer extends JpaRepository<com.hcl.hclassessment2.Entity.Customer, Long> {
}

