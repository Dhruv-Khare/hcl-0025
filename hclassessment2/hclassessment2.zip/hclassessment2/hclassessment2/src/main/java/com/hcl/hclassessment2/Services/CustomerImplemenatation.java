package com.hcl.hclassessment2.Services;

public class CustomerImplemenatation implements Customer{
    @Override
    public void addCustomer(Customer ustomer) {
        
    }
}
