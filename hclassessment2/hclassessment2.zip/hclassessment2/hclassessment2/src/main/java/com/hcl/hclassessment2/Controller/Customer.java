import com.hcl.hclassessment2.Repository.Customer;

@Autowired
private Customer myCustomer;

public void addNewRow(String value) {
    myCustomer entity = new myCustomer();
    entity.setNewColumn(value);
    myTableRepository.save(entity); // inserts into DB
}
