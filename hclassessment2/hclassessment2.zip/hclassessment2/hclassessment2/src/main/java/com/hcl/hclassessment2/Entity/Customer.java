package com.hcl.hclassessment2.Entity;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import jakarta.persistence.*;
@Entity
@Table(name = "customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "customerId")
    long customerId;

    @Column(name = "customerName")
    String customerName;

    @Column(name = "email")
    String customerEmail;

    @Column(name = "password")
    String password;

    @Column(name = "mobile")
    String mobile;

    @Column(name = "city")
    String city;



    public String getCity() {
        return city;
    }

    public String getPassword() {
        return password;
    }

    public String getMobile() {
        return mobile;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public String getCustomerName() {
        return customerName;
    }

    public long getCustomerId() {
        return customerId;
    }



    public void setCity(String city) {
        this.city = city;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

}
