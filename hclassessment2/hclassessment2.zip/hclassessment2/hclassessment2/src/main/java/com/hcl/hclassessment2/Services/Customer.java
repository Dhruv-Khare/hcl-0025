package com.hcl.hclassessment2.Services;

import org.springframework.stereotype.Service;

@Service
public interface Customer {
    public void addCustomer(Customer ustomer);
}
